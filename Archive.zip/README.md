# NAMES

# Dependencies 

    - mysql
    - cors
    - dotenv
    - express
    - mysql